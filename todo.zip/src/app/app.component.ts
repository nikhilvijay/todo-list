import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';3
import {FormsModule,ReactiveFormsModule} from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  date=new Date();
  showPop:boolean=false;

  newItem=new FormGroup({
    itmVal:new FormControl("")
  });

  itmVal:string="";
  
  list:any=[
    {item:"sample #1", state:false},
    {item:"sample #2", state:false},
    {item:"sample #3", state:false},
    {item:"sample #4", state:false},
    {item:"sample #5", state:false},
    {item:"sample #6", state:false}
  ]

  show(){
    this.showPop=true;
  }
  changeState(arg:number){
    this.list[arg]["state"] = !this.list[arg]["state"];
  }

  addItem(){
    console.log(this.newItem.value.itmVal)
    this.list.push({item:this.newItem.value.itmVal, state:false});
    this.showPop=false;
  }
}
